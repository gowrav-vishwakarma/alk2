<?php

class page_user_leveldetails extends page_user {
	function init(){
		parent::init();
		

	}
}