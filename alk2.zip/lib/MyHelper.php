<?php

class MyHelper extends AbstractController{
	function updateWallet(){
		
	}
}