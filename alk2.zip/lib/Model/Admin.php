<?php

class Model_Admin extends Model {

	
}