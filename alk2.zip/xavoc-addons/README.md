xavoc-addons
============


add the following code in your frontend class to enjoy further xavoc-addons for agile

$this->addLocation('.',array(
            "addons"=>'xavoc-addons'
            ));

For more information on each add-ons, read the file README in the add-ons folder
