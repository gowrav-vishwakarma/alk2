<?php
class Controller_Doc_Howto extends Controller {
	public $model_name='Model_Doc_Howto';
}
