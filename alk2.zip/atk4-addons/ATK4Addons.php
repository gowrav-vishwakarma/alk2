<?
class addon_atk4addons extends AbstractAddon {
	// add this into your application to activate addons
	function init(){
		parent::init();
	}
}
