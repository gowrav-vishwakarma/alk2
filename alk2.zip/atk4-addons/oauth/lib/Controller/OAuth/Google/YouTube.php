<?php
namespace oauth;
class Controller_OAuth_Google_YouTube extends Controller_OAuth_Google {
    protected $scope = "http://gdata.youtube.com";
}
