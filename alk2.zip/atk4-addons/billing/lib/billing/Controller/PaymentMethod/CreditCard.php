<?php
class billing_Controller_PaymentMethod_CreditCard extends ATK3_Controller{
	protected $model_name='billing_Model_PaymentMethod_CreditCard';
}
