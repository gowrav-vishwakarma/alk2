<?php

class page_oppertunity extends Page {
	function init(){
		parent::init();

	}

	function defaultTemplate(){
		return array('page/oppertunity');
	}
}